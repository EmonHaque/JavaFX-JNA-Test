import com.sun.jna.Callback;
import com.sun.jna.Library;

public interface CallbackWrapper extends Library {
    interface ICallback extends Callback {
        void call(Person person);
    }
    void keepCallingJavaFunction(int times);
    void setJavaCallback(ICallback action);
}