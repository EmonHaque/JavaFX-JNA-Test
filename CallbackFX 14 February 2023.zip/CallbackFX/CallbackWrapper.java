import com.sun.jna.Callback;
import com.sun.jna.Native;

public class CallbackWrapper {
    static {
        Native.register("/home/emon/LibCallback//call.so");
    }

    interface ICallback extends Callback {
        void call(Person person);
    }
    // why use public static native before function when you've to instantiate to get the native library loaded in the static constructor/block?
    native void keepCallingJavaFunction(int times);
    native void setJavaCallback(ICallback action);
}