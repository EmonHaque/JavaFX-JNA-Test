import com.sun.jna.Structure;

@Structure.FieldOrder({"age", "name"})
public class Person extends Structure {
    public int age;
    public String name;
}
