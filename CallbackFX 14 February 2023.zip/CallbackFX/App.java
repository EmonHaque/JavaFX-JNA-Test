import com.sun.jna.Function;
import com.sun.jna.Native;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class App extends Application {
    private CallbackWrapper cb;
    private Function sumInteger;

    @Override
    public void init() throws Exception {
        super.init();
        var nativeLib = "/home/emon/LibCallback//call.so";
        cb = Native.load(nativeLib, CallbackWrapper.class);
        CallbackWrapper.ICallback callback = p -> System.out.println("Java function called from C " + p.name + " age: " + p.age);
        cb.setJavaCallback(callback);
        sumInteger = Function.getFunction(nativeLib, "sumInteger");
    }

    @Override
    public void start(Stage stage) {
        var button = new Button("Start"){{
            setOnAction(e -> {
                int times = 3;
                cb.keepCallingJavaFunction(times);
                for (int i = 1; i < times + 1; i++){
                    var sum = sumInteger.invokeInt(new Object[]{ i, i});
                    System.out.println("C function called from Java " + sum);
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            });
        }};
        stage.setScene(new Scene(button, 200, 200));
        stage.show();
    }
}
