#!/bin/bash

# generate object file
gcc -c -fpic -o objectfile.o \
Source/*.c \
-IHeader

# generate shared library
gcc -shared -o sqlitejna.so objectfile.o \
-lsqlite3 

# delete object file
rm objectfile.o

# for debugging / core dumping
# gcc -g -o test Source/*.c -IHeader -lsqlite3 