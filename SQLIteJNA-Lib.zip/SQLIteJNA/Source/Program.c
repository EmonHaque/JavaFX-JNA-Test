#include "Program.h"
#include <sqlite3.h>

sqlite3 *db;
rowAction *addRow;
columnAction *addColumn;
errorAction *addError;
unsigned char isColumnCallNeeded;
int rowLength;

void setRowCallback(rowAction action) {
    addRow = action;
}

void setColumnCallback(columnAction action) {
    addColumn = action;
}

void setCErrorCallback(errorAction action) {
    addError = action;
}

static int callback(void *arg4, int count, char **values, char **columns) {
    if (isColumnCallNeeded) {
        isColumnCallNeeded = 0;
        rowLength = count * sizeof(char *);
        addColumn(count, columns, rowLength);
    }
    addRow(values);
    return 0;
}

void execute(char *query) {
    isColumnCallNeeded = 1;
    char *error;
    sqlite3_exec(db, query, callback, 0, &error);
    addError(error);
    sqlite3_free(error);
}

void openDatabase(char *dbFile) {
    if (db)  sqlite3_close(db);
    int result = sqlite3_open(dbFile, &db);
}

void closeDatabase() {
    if (db) sqlite3_close(db);
}

// int main(){
//     isColumn = 1;
//     sqlite3_open("/mnt/HDD/Corpus Quran/quran.db", &db);
//     sqlite3_exec(db, "select * from tenants", callback, 0, 0);
// }