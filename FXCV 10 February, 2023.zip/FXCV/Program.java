import com.sun.jna.Native;
import javafx.application.Application;
import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;

public class Program extends Application {
    private TessCV tessCV;
    private GridPane buttons;
    private ImageView view;
    private Image image;
    private Text fileName;
    private TextArea extracted;
    private double zoomLevel = 1;

    private void setImage(ImageCV imageCV) {
        var array = imageCV.data.getByteArray(0, imageCV.size);
        BufferedImage bufferedImage;
        try {
            bufferedImage = ImageIO.read(new ByteArrayInputStream(array));
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        image = SwingFXUtils.toFXImage(bufferedImage, null);
        view.setImage(image);
    }

    private void initializeButtons() {
        var gray = new Button("gray") {{
            setOnAction(e -> setImage(tessCV.getGrayImage()));
        }};
        var grayInverted = new Button("gray inverted") {{
            setOnAction(e -> setImage(tessCV.getInvertedGrayImage()));
        }};
        var color = new Button("color") {{
            setOnAction(e -> setImage(tessCV.getOriginalImage()));
        }};

        var blackWhite = new Button("black white") {{
            setOnAction(e -> setImage(tessCV.getBlackAndWhite()));
        }};

        var choose = new Button("choose JPEG") {{
            setOnAction(e -> {
                var chooser = new FileChooser();
                chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("JPEG", "*.jpg"));
                var file = chooser.showOpenDialog(null);
                if (file == null) return;
                var path = file.getAbsolutePath();
                fileName.setText(file.getName());
                tessCV.setImage(path);
                extracted.setText(tessCV.getText(path));
                setImage(tessCV.getOriginalImage());
            });
        }};
        fileName = new Text();


        var isDisabled = fileName.textProperty().isEmpty();
        gray.disableProperty().bind(isDisabled);
        color.disableProperty().bind(isDisabled);
        grayInverted.disableProperty().bind(isDisabled);
        blackWhite.disableProperty().bind(isDisabled);
        buttons = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints(),
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}}
            );
            add(new HBox(gray, color, grayInverted, blackWhite) {{setSpacing(2);}}, 0, 0);
            add(new HBox(fileName, choose) {{setAlignment(Pos.CENTER_RIGHT); setSpacing(10);}}, 1, 0);
        }};
    }

    private void onControlScroll(ScrollEvent e) {
        if(image == null)  return;
        if (!e.isControlDown())  return;
        // this function is called twice on every scroll, first with 0
        if (e.getDeltaY() == 0)  return;

        e.consume();
        zoomLevel *= e.getDeltaY() > 0 ? 1.05 : 0.95;

        view.setFitWidth(image.getWidth() * zoomLevel);
        view.setFitHeight(image.getHeight() * zoomLevel);
    }

    @Override
    public void init() throws Exception {
        super.init();
        tessCV = Native.load("/home/emon/LibTessCV/tesscv.so", TessCV.class);
        tessCV.initialize("/home/emon/IdeaProjects/Bills/resources/tessData", "eng");
        tessCV.setWhiteList("01234567890.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ -:'\"`~@#$%^&*()-=+_/<>?\\;,:[]{}|");
    }

    @Override
    public void start(Stage stage) {
        initializeButtons();
        view = new ImageView();
        extracted = new TextArea();
        var scroll = new ScrollPane(view){{
            setPannable(true);
            addEventFilter(ScrollEvent.SCROLL, Program.this::onControlScroll);
        }};

        var root = new GridPane() {{
            getRowConstraints().addAll(
                    new RowConstraints(),
                    new RowConstraints() {{setVgrow(Priority.ALWAYS);}}
            );
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setPercentWidth(65);}},
                    new ColumnConstraints() {{setPercentWidth(35);}}
            );
            add(buttons, 0, 0, 2, 1);
            add(scroll, 0, 1);
            add(extracted, 1, 1);
        }};
        stage.setScene(new Scene(root, 800, 640));
        stage.show();
    }

    @Override
    public void stop() throws Exception {
        tessCV.destroy();
        super.stop();
    }
}
