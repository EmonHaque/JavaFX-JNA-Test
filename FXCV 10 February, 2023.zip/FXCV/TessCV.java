import com.sun.jna.Library;

public interface TessCV extends Library {
    void initialize(String dataPath, String language);
    void setWhiteList(String characters);
    String getText(String file);
    void setImage(String file);
    ImageCV getGrayImage();
    ImageCV getInvertedGrayImage();
    ImageCV getOriginalImage();
    ImageCV getBlackAndWhite();
    void destroy();
}