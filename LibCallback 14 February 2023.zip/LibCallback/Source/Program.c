#include "Program.h"
#include <stdio.h>
#include <unistd.h>
#include <malloc.h>

Action *callback;
int current = 0;
const int milis = 500 * 1000;

void setJavaCallback(Action action){
    callback = action;
}

void keepCallingJavaFunction(int times){
    for(int i = 0; i < times; i++){
        current++;
        char name[50];
        sprintf(name, "Some person %d", current);
        // Person p = { current + 10, name };
        // callback(&p);
        callback(&(Person){ current + 10, name });
        usleep(milis);
    }
}

int sumInteger(int x, int y){
    return x + y;
}