#!/bin/bash

#generate object file
gcc -c -fpic -o objectfile.o \
Source/*.c \
-IHeader

#generate shared library
gcc -shared -o call.so objectfile.o \

# delete object file
rm objectfile.o