#pragma once

typedef struct{
    int age;
    char *name;
} Person;

typedef void Action(Person *p);