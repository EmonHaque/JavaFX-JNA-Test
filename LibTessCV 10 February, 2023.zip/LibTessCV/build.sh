#!/bin/bash

#generate object file
g++ -c -fpic -o objectfile.o \
Source/*.cpp \
-I/usr/include/opencv4 \
-IHeader

#generate shared library
g++ -shared -o tesscv.so objectfile.o \
-ltesseract \
-lleptonica \
-lopencv_stitching \
-lopencv_objdetect \
-lopencv_calib3d \
-lopencv_features2d \
-lopencv_highgui \
-lopencv_videoio \
-lopencv_imgcodecs \
-lopencv_video \
-lopencv_photo \
-lopencv_ml \
-lopencv_imgproc \
-lopencv_flann \
-lopencv_core

# delete object file
rm objectfile.o