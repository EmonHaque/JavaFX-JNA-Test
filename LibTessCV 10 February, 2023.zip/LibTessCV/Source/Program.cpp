#include <tesseract/baseapi.h>
#include <leptonica/allheaders.h>
#include <opencv2/opencv.hpp>

#include "Program.h"

using namespace std;
using namespace cv;
using namespace tesseract;

TessBaseAPI *tess;
Mat current;
vector<uchar> buffer;
ImageCV *image = { 0 };
char *text = { 0 };

ImageCV* getImage(){
    if(image) free(image);

    image = (ImageCV*)malloc(sizeof(ImageCV));
    image->size = (int)buffer.size();
    image->data = buffer.begin().base();

    return image;
}

extern "C" void initialize(char *dataPath, char *language){
    tess = new TessBaseAPI();
    tess->Init(dataPath, language, OEM_LSTM_ONLY);
}

extern "C" void setWhiteList(char *characters){
    tess->SetVariable("tessedit_char_whitelist", characters);
}

extern "C" char *getText(char *file){
    if(text) delete [] text;

    Mat im = imread(file, IMREAD_UNCHANGED);
    Mat gray, binary;

    cvtColor(im, gray, COLOR_BGR2GRAY);
    threshold(gray, binary, 200, 255, THRESH_BINARY);

    tess->SetImage(binary.data, binary.cols, binary.rows, binary.channels(), binary.step);
    tess->SetSourceResolution(96);
    text = tess->GetUTF8Text();
    return text;
}

extern "C" void setImage(char * file){
    current = imread(file, IMREAD_UNCHANGED);
}

extern "C" ImageCV* getOriginalImage(){
    imencode(".png", current, buffer);

    return getImage();
}

extern "C" ImageCV* getGrayImage(){
    Mat gray;
    cvtColor(current, gray, COLOR_BGR2GRAY);
    imencode(".png", gray, buffer);

    return getImage();
}

extern "C" ImageCV* getInvertedGrayImage(){
    Mat gray, inverted;
    cvtColor(current, gray, COLOR_BGR2GRAY);
    bitwise_not(gray, inverted);
    imencode(".png", inverted, buffer);

    return getImage();
}

extern "C" ImageCV* getBlackAndWhite(){
    Mat gray, binary, inverted;
    cvtColor(current, gray, COLOR_BGR2GRAY);
    threshold(gray, binary, 200, 255, THRESH_BINARY);
    bitwise_not(binary, inverted);
    imencode(".png", inverted, buffer);

    return getImage();
}

extern "C" void destroy(){
    tess->End();
    if(image) free(image);
    if(text) delete [] text;
    delete tess;
}