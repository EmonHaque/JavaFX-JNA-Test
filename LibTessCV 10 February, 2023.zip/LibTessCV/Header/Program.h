#pragma once

typedef struct {
    int size;
    unsigned char *data;
} ImageCV;