import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class App extends Application {
    private NativeWrapper wrapper;
    private NativeWrapper.columnCallback colCall;
    private NativeWrapper.rowCallBack rowCall;
    private NativeWrapper.errorCallback errCall;

    private TableView<String[]> tableView;
    private ObservableList<String[]> list;

    private Button execute;
    private TextArea queryArea;
    private int numRow;
    private Text row, time, error;
    private int columnCount, pointerLength;

    @Override
    public void init() throws Exception {
        super.init();

        list = FXCollections.observableArrayList();
        wrapper = new NativeWrapper();
        wrapper.openDatabase("/mnt/HDD/Corpus Quran/quran.db");

        colCall = (count, values, length) -> {
            columnCount = count;
            pointerLength = length;
            var pointers = values.getPointer().getPointerArray(0, length);
            var array = new String[count];
            for (int i = 0; i < count; i++) {
                array[i] = pointers[i].getString(0);
            }
            for (int i = 0; i < count; i++) {
                var col = new TableColumn<String[], String>(array[i]);
                final int index = i;
                col.setCellValueFactory(v -> new SimpleStringProperty(v.getValue()[index]));
                tableView.getColumns().add(col);
            }
        };
        rowCall = (values) -> {
            var pointers = values.getPointer().getPointerArray(0, pointerLength);
            var array = new String[columnCount];
            for (int i = 0; i < columnCount; i++) {
                array[i] = pointers[i] == null ? "NULL" : pointers[i].getString(0);
            }
            list.add(array);
            numRow++;
        };
        errCall = err ->{
            if(err == null){
                error.setFill(Color.DARKGREEN);
                error.setText("OK");
            }
            else{
                error.setFill(Color.RED);
                error.setText(err);
            }
        };

        wrapper.setColumnCallback(colCall);
        wrapper.setRowCallback(rowCall);
        wrapper.setCErrorCallback(errCall);
    }

    @Override
    public void start(Stage stage) {
        tableView = new TableView<>(){{ setBackground(null);}};
        tableView.setItems(list);
        queryArea = new TextArea();
        var split = new SplitPane();
        split.getItems().addAll(queryArea, tableView);

        execute = new Button("Execute") {{
            setOnAction(e -> {
                var start = System.currentTimeMillis();
                numRow = 0;
                tableView.getColumns().clear();
                list.clear();

                var query = queryArea.getText();
                wrapper.execute(query);
                time.setText(System.currentTimeMillis() - start + " ms.");
                row.setText(String.format("%,d", numRow) + " rows");
            });
        }};

        row = new Text();
        time = new Text();
        error = new Text();
        var bottomBox = new HBox(execute, row, time){{
            setSpacing(10);
            setAlignment(Pos.CENTER_LEFT);
        }};
        var bottom = new BorderPane(){{
            setCenter(bottomBox);
            setRight(error);
            setAlignment(error, Pos.CENTER_RIGHT);
        }};
        var border = new BorderPane() {{
            setCenter(split);
            setBottom(bottom);
        }};

        stage.setScene(new Scene(border, 640, 480));
        stage.show();
    }

    @Override
    public void stop() throws Exception {
        wrapper.closeDatabase();
        super.stop();
    }
}
