import com.sun.jna.Callback;
import com.sun.jna.Native;
import com.sun.jna.ptr.PointerByReference;

public class NativeWrapper {
    static {
        Native.register("/home/emon/SQLIteJNA/sqlitejna.so");
    }
    interface rowCallBack extends Callback{
        void invoke(PointerByReference values);
    }
    interface columnCallback extends Callback{
        void invoke(int count, PointerByReference values, int length);
    }
    interface errorCallback extends Callback{
        void invoke(String text);
    }
    native void setRowCallback(rowCallBack action);
    native void setColumnCallback(columnCallback action);
    native void setCErrorCallback(errorCallback action);
    native void openDatabase(String dbFile);
    native void execute(String query);
    native void closeDatabase();
}
